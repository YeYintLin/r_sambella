var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/_core/env.ts
var ENV;
var init_env = __esm({
  "server/_core/env.ts"() {
    "use strict";
    ENV = {
      appId: process.env.VITE_APP_ID ?? "",
      cookieSecret: process.env.JWT_SECRET ?? "",
      databaseUrl: process.env.DATABASE_URL ?? "",
      oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
      ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
      isProduction: process.env.NODE_ENV === "production",
      forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
      forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
      odooUrl: process.env.ODOO_URL ?? "",
      odooUsername: process.env.ODOO_USERNAME ?? "",
      odooPassword: process.env.ODOO_PASSWORD ?? "",
      odooDatabase: process.env.ODOO_DATABASE ?? "",
      odooTeamId: process.env.ODOO_TEAM_ID ?? "",
      odooTeamName: process.env.ODOO_TEAM_NAME ?? "",
      odooLeadType: process.env.ODOO_LEAD_TYPE ?? "",
      odooUserId: process.env.ODOO_USER_ID ?? "",
      odooUserName: process.env.ODOO_USER_NAME ?? "",
      odooUserLogin: process.env.ODOO_USER_LOGIN ?? ""
    };
  }
});

// server/odoo.ts
var odoo_exports = {};
__export(odoo_exports, {
  getOdooClient: () => getOdooClient,
  testOdooConnection: () => testOdooConnection
});
import axios2 from "axios";
async function getOdooClient() {
  if (!ENV.odooUrl || !ENV.odooUsername || !ENV.odooPassword) {
    console.warn("[Odoo] Missing credentials in environment variables");
    return null;
  }
  if (odooClient) {
    return odooClient;
  }
  odooClient = new OdooClient(
    ENV.odooUrl,
    ENV.odooUsername,
    ENV.odooPassword,
    ENV.odooDatabase
  );
  const authenticated = await odooClient.authenticate();
  if (!authenticated) {
    console.error("[Odoo] Failed to authenticate");
    odooClient = null;
    return null;
  }
  return odooClient;
}
async function testOdooConnection() {
  const client = await getOdooClient();
  return client !== null;
}
var OdooClient, odooClient;
var init_odoo = __esm({
  "server/odoo.ts"() {
    "use strict";
    init_env();
    OdooClient = class {
      baseUrl;
      username;
      password;
      database;
      uid = null;
      constructor(baseUrl, username, password, database) {
        let cleanUrl = baseUrl.replace(/\/$/, "");
        if (cleanUrl.endsWith("/odoo")) {
          cleanUrl = cleanUrl.slice(0, -5);
        }
        this.baseUrl = cleanUrl;
        this.username = username;
        this.password = password;
        this.database = database || "";
      }
      /**
       * Authenticate with Odoo using JSON-RPC
       */
      async authenticate() {
        try {
          console.log(`[Odoo] Attempting authentication at: ${this.baseUrl}/jsonrpc`);
          const response = await axios2.post(
            `${this.baseUrl}/jsonrpc`,
            {
              jsonrpc: "2.0",
              method: "call",
              params: {
                service: "common",
                method: "authenticate",
                args: [this.database, this.username, this.password, {}]
              },
              id: 1
            },
            {
              timeout: 15e3,
              headers: {
                "Content-Type": "application/json"
              }
            }
          );
          console.log("[Odoo] Auth response:", JSON.stringify(response.data).substring(0, 200));
          if (response.data.error) {
            console.error("[Odoo Auth Error]", response.data.error);
            return false;
          }
          if (!response.data.result) {
            console.error("[Odoo Auth Error] No UID returned");
            return false;
          }
          this.uid = response.data.result;
          console.log(`[Odoo] Authenticated successfully as UID: ${this.uid}`);
          return true;
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : String(error);
          console.error("[Odoo Auth Failed]", errorMsg);
          if (axios2.isAxiosError(error) && error.response) {
            console.error("[Odoo Response Status]", error.response.status);
            console.error("[Odoo Response Data]", JSON.stringify(error.response.data).substring(0, 500));
          }
          return false;
        }
      }
      /**
       * Call Odoo RPC method
       */
      async rpcCall(model, method, args = [], kwargs = {}) {
        if (!this.uid) {
          throw new Error("Not authenticated with Odoo");
        }
        try {
          const response = await axios2.post(
            `${this.baseUrl}/jsonrpc`,
            {
              jsonrpc: "2.0",
              method: "call",
              params: {
                service: "object",
                method: "execute",
                args: [this.database, this.uid, this.password, model, method, ...args],
                kwargs
              },
              id: 1
            },
            {
              timeout: 15e3,
              headers: {
                "Content-Type": "application/json"
              }
            }
          );
          if (response.data.error) {
            console.error(`[Odoo RPC Error] ${model}.${method}:`, response.data.error);
            throw new Error(
              typeof response.data.error === "object" ? response.data.error.data?.message || JSON.stringify(response.data.error) : String(response.data.error)
            );
          }
          return response.data.result;
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : String(error);
          console.error(`[Odoo RPC Failed] ${model}.${method}:`, errorMsg);
          throw error;
        }
      }
      async search(model, domain = [], limit = 1) {
        const result = await this.rpcCall(model, "search", [domain, 0, limit]);
        return result ?? [];
      }
      async getTeamIdByName(teamName) {
        if (!teamName) return null;
        try {
          const ids = await this.search("crm.team", [["name", "=", teamName]], 1);
          return ids.length > 0 ? ids[0] : null;
        } catch (error) {
          console.error("[Odoo] Failed to resolve team name:", error);
          return null;
        }
      }
      async getUserIdByName(name) {
        if (!name) return null;
        try {
          const ids = await this.search("res.users", [["name", "=", name]], 1);
          return ids.length > 0 ? ids[0] : null;
        } catch (error) {
          console.error("[Odoo] Failed to resolve user name:", error);
          return null;
        }
      }
      async getUserIdByLogin(login) {
        if (!login) return null;
        try {
          const ids = await this.search("res.users", [["login", "=", login]], 1);
          return ids.length > 0 ? ids[0] : null;
        } catch (error) {
          console.error("[Odoo] Failed to resolve user login:", error);
          return null;
        }
      }
      /**
       * Get CRM leads
       */
      async getLeads(limit = 100, options) {
        try {
          const domain = [];
          if (options?.leadType) {
            domain.push(["type", "=", options.leadType]);
          }
          if (options?.teamId) {
            domain.push(["team_id", "=", options.teamId]);
          } else if (options?.teamName) {
            const teamId = await this.getTeamIdByName(options.teamName);
            if (teamId) {
              domain.push(["team_id", "=", teamId]);
            } else {
              console.warn(`[Odoo] Team name not found: ${options.teamName}. Fetching all teams.`);
            }
          }
          if (options?.userId) {
            domain.push(["user_id", "=", options.userId]);
          } else if (options?.userName) {
            const userId = await this.getUserIdByName(options.userName);
            if (userId) {
              domain.push(["user_id", "=", userId]);
            } else {
              console.warn(`[Odoo] User name not found: ${options.userName}.`);
            }
          } else if (options?.userLogin) {
            const userId = await this.getUserIdByLogin(options.userLogin);
            if (userId) {
              domain.push(["user_id", "=", userId]);
            } else {
              console.warn(`[Odoo] User login not found: ${options.userLogin}.`);
            }
          }
          const leadIds = await this.rpcCall("crm.lead", "search", [domain, 0, limit]);
          if (!leadIds || leadIds.length === 0) return [];
          const leads = await this.rpcCall("crm.lead", "read", [
            leadIds,
            [
              "id",
              "name",
              "email_from",
              "stage_id",
              "probability",
              "expected_revenue",
              "create_date",
              "partner_id",
              "phone",
              "description"
            ]
          ]);
          return leads;
        } catch (error) {
          console.error("[Odoo] Failed to fetch leads:", error);
          return [];
        }
      }
      /**
       * Get sales orders
       */
      async getSalesOrders(limit = 100) {
        try {
          const orderIds = await this.rpcCall("sale.order", "search", [
            [["state", "in", ["sale", "done"]]],
            0,
            limit
          ]);
          if (!orderIds || orderIds.length === 0) return [];
          const orders = await this.rpcCall("sale.order", "read", [
            orderIds,
            ["id", "name", "partner_id", "amount_total", "state", "create_date"]
          ]);
          return orders;
        } catch (error) {
          console.error("[Odoo] Failed to fetch sales orders:", error);
          return [];
        }
      }
      /**
       * Get manufacturing orders (if manufacturing module is installed)
       */
      async getManufacturingOrders(limit = 100) {
        try {
          const moIds = await this.rpcCall("mrp.production", "search", [[], 0, limit]);
          if (!moIds || moIds.length === 0) return [];
          const orders = await this.rpcCall("mrp.production", "read", [
            moIds,
            ["id", "name", "state", "product_id", "product_qty", "create_date"]
          ]);
          return orders;
        } catch (error) {
          console.error("[Odoo] Failed to fetch manufacturing orders:", error);
          return [];
        }
      }
      /**
       * Get inventory data
       */
      async getInventory(limit = 100) {
        try {
          const productIds = await this.rpcCall("product.product", "search", [[], 0, limit]);
          if (!productIds || productIds.length === 0) return [];
          const products = await this.rpcCall("product.product", "read", [
            productIds,
            ["id", "name", "qty_available", "virtual_available"]
          ]);
          return products;
        } catch (error) {
          console.error("[Odoo] Failed to fetch inventory:", error);
          return [];
        }
      }
    };
    odooClient = null;
  }
});

// server/_core/index.ts
import "dotenv/config";
import express2 from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";

// shared/const.ts
var COOKIE_NAME = "app_session_id";
var ONE_YEAR_MS = 1e3 * 60 * 60 * 24 * 365;
var AXIOS_TIMEOUT_MS = 3e4;
var UNAUTHED_ERR_MSG = "Please login (10001)";
var NOT_ADMIN_ERR_MSG = "You do not have required permission (10002)";

// server/db.ts
import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";

// drizzle/schema.ts
import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";
var users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull()
});
var opportunities = mysqlTable("opportunities", {
  id: int("id").autoincrement().primaryKey(),
  odooId: int("odooId").notNull().unique(),
  // Reference to Odoo opportunity ID
  name: varchar("name", { length: 255 }).notNull(),
  // Opportunity name
  stage: varchar("stage", { length: 100 }).notNull(),
  // Pipeline stage (New, Qualified, Proposition, Won, etc.)
  amount: int("amount").notNull().default(0),
  // Amount in currency
  probability: int("probability").notNull().default(0),
  // Probability percentage (0-100)
  expectedRevenue: int("expectedRevenue").notNull().default(0),
  // Expected revenue
  partnerName: varchar("partnerName", { length: 255 }),
  // Customer/Partner name
  email: varchar("email", { length: 320 }),
  // Contact email
  phone: varchar("phone", { length: 20 }),
  // Contact phone
  description: text("description"),
  // Additional notes
  rating: int("rating").notNull().default(0),
  // Star rating (0-5)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  syncedAt: timestamp("syncedAt").defaultNow().notNull()
  // Last sync from Odoo
});

// server/db.ts
init_env();
var _db = null;
async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}
async function upsertUser(user) {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values = {
      openId: user.openId
    };
    const updateSet = {};
    const textFields = ["name", "email", "loginMethod"];
    const assignNullable = (field) => {
      const value = user[field];
      if (value === void 0) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== void 0) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== void 0) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) {
      values.lastSignedIn = /* @__PURE__ */ new Date();
    }
    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = /* @__PURE__ */ new Date();
    }
    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}
async function getUserByOpenId(openId) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return void 0;
  }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : void 0;
}

// server/_core/cookies.ts
function isSecureRequest(req) {
  if (req.protocol === "https") return true;
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;
  const protoList = Array.isArray(forwardedProto) ? forwardedProto : forwardedProto.split(",");
  return protoList.some((proto) => proto.trim().toLowerCase() === "https");
}
function getSessionCookieOptions(req) {
  return {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: isSecureRequest(req)
  };
}

// shared/_core/errors.ts
var HttpError = class extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.name = "HttpError";
  }
};
var ForbiddenError = (msg) => new HttpError(403, msg);

// server/_core/sdk.ts
import axios from "axios";
import { parse as parseCookieHeader } from "cookie";
import { SignJWT, jwtVerify } from "jose";
init_env();
var isNonEmptyString = (value) => typeof value === "string" && value.length > 0;
var EXCHANGE_TOKEN_PATH = `/webdev.v1.WebDevAuthPublicService/ExchangeToken`;
var GET_USER_INFO_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfo`;
var GET_USER_INFO_WITH_JWT_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfoWithJwt`;
var OAuthService = class {
  constructor(client) {
    this.client = client;
    console.log("[OAuth] Initialized with baseURL:", ENV.oAuthServerUrl);
    if (!ENV.oAuthServerUrl) {
      console.error(
        "[OAuth] ERROR: OAUTH_SERVER_URL is not configured! Set OAUTH_SERVER_URL environment variable."
      );
    }
  }
  decodeState(state) {
    const redirectUri = atob(state);
    return redirectUri;
  }
  async getTokenByCode(code, state) {
    const payload = {
      clientId: ENV.appId,
      grantType: "authorization_code",
      code,
      redirectUri: this.decodeState(state)
    };
    const { data } = await this.client.post(
      EXCHANGE_TOKEN_PATH,
      payload
    );
    return data;
  }
  async getUserInfoByToken(token) {
    const { data } = await this.client.post(
      GET_USER_INFO_PATH,
      {
        accessToken: token.accessToken
      }
    );
    return data;
  }
};
var createOAuthHttpClient = () => axios.create({
  baseURL: ENV.oAuthServerUrl,
  timeout: AXIOS_TIMEOUT_MS
});
var SDKServer = class {
  client;
  oauthService;
  constructor(client = createOAuthHttpClient()) {
    this.client = client;
    this.oauthService = new OAuthService(this.client);
  }
  deriveLoginMethod(platforms, fallback) {
    if (fallback && fallback.length > 0) return fallback;
    if (!Array.isArray(platforms) || platforms.length === 0) return null;
    const set = new Set(
      platforms.filter((p) => typeof p === "string")
    );
    if (set.has("REGISTERED_PLATFORM_EMAIL")) return "email";
    if (set.has("REGISTERED_PLATFORM_GOOGLE")) return "google";
    if (set.has("REGISTERED_PLATFORM_APPLE")) return "apple";
    if (set.has("REGISTERED_PLATFORM_MICROSOFT") || set.has("REGISTERED_PLATFORM_AZURE"))
      return "microsoft";
    if (set.has("REGISTERED_PLATFORM_GITHUB")) return "github";
    const first = Array.from(set)[0];
    return first ? first.toLowerCase() : null;
  }
  /**
   * Exchange OAuth authorization code for access token
   * @example
   * const tokenResponse = await sdk.exchangeCodeForToken(code, state);
   */
  async exchangeCodeForToken(code, state) {
    return this.oauthService.getTokenByCode(code, state);
  }
  /**
   * Get user information using access token
   * @example
   * const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
   */
  async getUserInfo(accessToken) {
    const data = await this.oauthService.getUserInfoByToken({
      accessToken
    });
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  parseCookies(cookieHeader) {
    if (!cookieHeader) {
      return /* @__PURE__ */ new Map();
    }
    const parsed = parseCookieHeader(cookieHeader);
    return new Map(Object.entries(parsed));
  }
  getSessionSecret() {
    const secret = ENV.cookieSecret;
    return new TextEncoder().encode(secret);
  }
  /**
   * Create a session token for a Manus user openId
   * @example
   * const sessionToken = await sdk.createSessionToken(userInfo.openId);
   */
  async createSessionToken(openId, options = {}) {
    return this.signSession(
      {
        openId,
        appId: ENV.appId,
        name: options.name || ""
      },
      options
    );
  }
  async signSession(payload, options = {}) {
    const issuedAt = Date.now();
    const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
    const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1e3);
    const secretKey = this.getSessionSecret();
    return new SignJWT({
      openId: payload.openId,
      appId: payload.appId,
      name: payload.name
    }).setProtectedHeader({ alg: "HS256", typ: "JWT" }).setExpirationTime(expirationSeconds).sign(secretKey);
  }
  async verifySession(cookieValue) {
    if (!cookieValue) {
      console.warn("[Auth] Missing session cookie");
      return null;
    }
    try {
      const secretKey = this.getSessionSecret();
      const { payload } = await jwtVerify(cookieValue, secretKey, {
        algorithms: ["HS256"]
      });
      const { openId, appId, name } = payload;
      if (!isNonEmptyString(openId) || !isNonEmptyString(appId) || !isNonEmptyString(name)) {
        console.warn("[Auth] Session payload missing required fields");
        return null;
      }
      return {
        openId,
        appId,
        name
      };
    } catch (error) {
      console.warn("[Auth] Session verification failed", String(error));
      return null;
    }
  }
  async getUserInfoWithJwt(jwtToken) {
    const payload = {
      jwtToken,
      projectId: ENV.appId
    };
    const { data } = await this.client.post(
      GET_USER_INFO_WITH_JWT_PATH,
      payload
    );
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  async authenticateRequest(req) {
    const cookies = this.parseCookies(req.headers.cookie);
    const sessionCookie = cookies.get(COOKIE_NAME);
    const session = await this.verifySession(sessionCookie);
    if (!session) {
      throw ForbiddenError("Invalid session cookie");
    }
    const sessionUserId = session.openId;
    const signedInAt = /* @__PURE__ */ new Date();
    let user = await getUserByOpenId(sessionUserId);
    if (!user) {
      try {
        const userInfo = await this.getUserInfoWithJwt(sessionCookie ?? "");
        await upsertUser({
          openId: userInfo.openId,
          name: userInfo.name || null,
          email: userInfo.email ?? null,
          loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
          lastSignedIn: signedInAt
        });
        user = await getUserByOpenId(userInfo.openId);
      } catch (error) {
        console.error("[Auth] Failed to sync user from OAuth:", error);
        throw ForbiddenError("Failed to sync user info");
      }
    }
    if (!user) {
      throw ForbiddenError("User not found");
    }
    await upsertUser({
      openId: user.openId,
      lastSignedIn: signedInAt
    });
    return user;
  }
};
var sdk = new SDKServer();

// server/_core/oauth.ts
function getQueryParam(req, key) {
  const value = req.query[key];
  return typeof value === "string" ? value : void 0;
}
function registerOAuthRoutes(app) {
  app.get("/api/oauth/callback", async (req, res) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");
    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }
    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      if (!userInfo.openId) {
        res.status(400).json({ error: "openId missing from user info" });
        return;
      }
      await upsertUser({
        openId: userInfo.openId,
        name: userInfo.name || null,
        email: userInfo.email ?? null,
        loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
        lastSignedIn: /* @__PURE__ */ new Date()
      });
      const sessionToken = await sdk.createSessionToken(userInfo.openId, {
        name: userInfo.name || "",
        expiresInMs: ONE_YEAR_MS
      });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      res.redirect(302, "/");
    } catch (error) {
      console.error("[OAuth] Callback failed", error);
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });
}

// server/routers.ts
import { z as z2 } from "zod";

// server/_core/systemRouter.ts
import { z } from "zod";

// server/_core/notification.ts
init_env();
import { TRPCError } from "@trpc/server";
var TITLE_MAX_LENGTH = 1200;
var CONTENT_MAX_LENGTH = 2e4;
var trimValue = (value) => value.trim();
var isNonEmptyString2 = (value) => typeof value === "string" && value.trim().length > 0;
var buildEndpointUrl = (baseUrl) => {
  const normalizedBase = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  return new URL(
    "webdevtoken.v1.WebDevService/SendNotification",
    normalizedBase
  ).toString();
};
var validatePayload = (input) => {
  if (!isNonEmptyString2(input.title)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification title is required."
    });
  }
  if (!isNonEmptyString2(input.content)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification content is required."
    });
  }
  const title = trimValue(input.title);
  const content = trimValue(input.content);
  if (title.length > TITLE_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification title must be at most ${TITLE_MAX_LENGTH} characters.`
    });
  }
  if (content.length > CONTENT_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification content must be at most ${CONTENT_MAX_LENGTH} characters.`
    });
  }
  return { title, content };
};
async function notifyOwner(payload) {
  const { title, content } = validatePayload(payload);
  if (!ENV.forgeApiUrl) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service URL is not configured."
    });
  }
  if (!ENV.forgeApiKey) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service API key is not configured."
    });
  }
  const endpoint = buildEndpointUrl(ENV.forgeApiUrl);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        accept: "application/json",
        authorization: `Bearer ${ENV.forgeApiKey}`,
        "content-type": "application/json",
        "connect-protocol-version": "1"
      },
      body: JSON.stringify({ title, content })
    });
    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.warn(
        `[Notification] Failed to notify owner (${response.status} ${response.statusText})${detail ? `: ${detail}` : ""}`
      );
      return false;
    }
    return true;
  } catch (error) {
    console.warn("[Notification] Error calling notification service:", error);
    return false;
  }
}

// server/_core/trpc.ts
import { initTRPC, TRPCError as TRPCError2 } from "@trpc/server";
import superjson from "superjson";
var t = initTRPC.context().create({
  transformer: superjson
});
var router = t.router;
var publicProcedure = t.procedure;
var requireUser = t.middleware(async (opts) => {
  const { ctx, next } = opts;
  if (!ctx.user) {
    throw new TRPCError2({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }
  return next({
    ctx: {
      ...ctx,
      user: ctx.user
    }
  });
});
var protectedProcedure = t.procedure.use(requireUser);
var adminProcedure = t.procedure.use(
  t.middleware(async (opts) => {
    const { ctx, next } = opts;
    if (!ctx.user || ctx.user.role !== "admin") {
      throw new TRPCError2({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }
    return next({
      ctx: {
        ...ctx,
        user: ctx.user
      }
    });
  })
);

// server/_core/systemRouter.ts
var systemRouter = router({
  health: publicProcedure.input(
    z.object({
      timestamp: z.number().min(0, "timestamp cannot be negative")
    })
  ).query(() => ({
    ok: true
  })),
  notifyOwner: adminProcedure.input(
    z.object({
      title: z.string().min(1, "title is required"),
      content: z.string().min(1, "content is required")
    })
  ).mutation(async ({ input }) => {
    const delivered = await notifyOwner(input);
    return {
      success: delivered
    };
  })
});

// server/opportunities.db.ts
import { eq as eq2 } from "drizzle-orm";
async function getAllOpportunities() {
  const db = await getDb();
  if (!db) return [];
  try {
    return await db.select().from(opportunities);
  } catch (error) {
    console.error("[DB] Failed to get opportunities:", error);
    return [];
  }
}
async function getOpportunityByOdooId(odooId) {
  const db = await getDb();
  if (!db) return void 0;
  try {
    const result = await db.select().from(opportunities).where(eq2(opportunities.odooId, odooId)).limit(1);
    return result[0];
  } catch (error) {
    console.error("[DB] Failed to get opportunity by Odoo ID:", error);
    return void 0;
  }
}
async function upsertOpportunity(odooId, data) {
  const db = await getDb();
  if (!db) return void 0;
  try {
    const existing = await getOpportunityByOdooId(odooId);
    if (existing) {
      await db.update(opportunities).set({
        ...data,
        updatedAt: /* @__PURE__ */ new Date(),
        syncedAt: /* @__PURE__ */ new Date()
      }).where(eq2(opportunities.odooId, odooId));
      return await getOpportunityByOdooId(odooId);
    } else {
      await db.insert(opportunities).values({
        odooId,
        ...data
      });
      return await getOpportunityByOdooId(odooId);
    }
  } catch (error) {
    console.error("[DB] Failed to upsert opportunity:", error);
    return void 0;
  }
}

// server/mock-opportunities.ts
var mockOpportunities = [
  {
    id: 1,
    odooId: 1001,
    name: "Global Solutions: Furniture",
    stage: "Qualified",
    amount: 38e8,
    // 3,800,000 K
    probability: 75,
    expectedRevenue: 285e7,
    partnerName: "Ready Mat",
    email: "contact@readymat.com",
    phone: "+1-555-0101",
    description: "Large furniture order for office setup",
    rating: 3,
    createdAt: /* @__PURE__ */ new Date("2026-03-10"),
    updatedAt: /* @__PURE__ */ new Date("2026-03-18"),
    syncedAt: /* @__PURE__ */ new Date()
  },
  {
    id: 2,
    odooId: 1002,
    name: "Quote for 600 Chairs",
    stage: "Qualified",
    amount: 225e8,
    // 22,500,000 K
    probability: 60,
    expectedRevenue: 135e8,
    partnerName: "Erik N. French",
    email: "erik@example.com",
    phone: "+1-555-0102",
    description: "Commercial furniture quote",
    rating: 2,
    createdAt: /* @__PURE__ */ new Date("2026-03-12"),
    updatedAt: /* @__PURE__ */ new Date("2026-03-17"),
    syncedAt: /* @__PURE__ */ new Date()
  },
  {
    id: 3,
    odooId: 1003,
    name: "Modern Open Space",
    stage: "Proposition",
    amount: 45e8,
    // 4,500,000 K
    probability: 50,
    expectedRevenue: 225e7,
    partnerName: "Henry Jordan",
    email: "henry@example.com",
    phone: "+1-555-0103",
    description: "Modern office design project",
    rating: 2,
    createdAt: /* @__PURE__ */ new Date("2026-03-08"),
    updatedAt: /* @__PURE__ */ new Date("2026-03-15"),
    syncedAt: /* @__PURE__ */ new Date()
  },
  {
    id: 4,
    odooId: 1004,
    name: "Office Design and Architecture",
    stage: "Proposition",
    amount: 9e9,
    // 9,000,000 K
    probability: 45,
    expectedRevenue: 405e7,
    partnerName: "Ready Mat",
    email: "design@readymat.com",
    phone: "+1-555-0104",
    description: "Consulting services for office design",
    rating: 2,
    createdAt: /* @__PURE__ */ new Date("2026-03-05"),
    updatedAt: /* @__PURE__ */ new Date("2026-03-16"),
    syncedAt: /* @__PURE__ */ new Date()
  },
  {
    id: 5,
    odooId: 1005,
    name: "Info about services",
    stage: "Qualified",
    amount: 25e9,
    // 25,000,000 K
    probability: 40,
    expectedRevenue: 1e10,
    partnerName: "Acme Corporation",
    email: "info@acme.com",
    phone: "+1-555-0105",
    description: "Service inquiry",
    rating: 1,
    createdAt: /* @__PURE__ */ new Date("2026-03-01"),
    updatedAt: /* @__PURE__ */ new Date("2026-03-14"),
    syncedAt: /* @__PURE__ */ new Date()
  },
  {
    id: 6,
    odooId: 1006,
    name: "5 VP Chairs",
    stage: "Proposition",
    amount: 56e8,
    // 5,600,000 K
    probability: 35,
    expectedRevenue: 196e7,
    partnerName: "Azure Interior",
    email: "vp@azure.com",
    phone: "+1-555-0106",
    description: "Executive furniture order",
    rating: 1,
    createdAt: /* @__PURE__ */ new Date("2026-03-03"),
    updatedAt: /* @__PURE__ */ new Date("2026-03-13"),
    syncedAt: /* @__PURE__ */ new Date()
  },
  {
    id: 7,
    odooId: 1007,
    name: "Need 20 Desks",
    stage: "New",
    amount: 6e10,
    // 60,000,000 K
    probability: 25,
    expectedRevenue: 15e9,
    partnerName: "Unknown",
    email: null,
    phone: null,
    description: "Initial desk inquiry",
    rating: 0,
    createdAt: /* @__PURE__ */ new Date("2026-03-19"),
    updatedAt: /* @__PURE__ */ new Date("2026-03-19"),
    syncedAt: /* @__PURE__ */ new Date()
  },
  {
    id: 8,
    odooId: 1008,
    name: "Distributor Contract",
    stage: "Won",
    amount: 198e8,
    // 19,800,000 K
    probability: 100,
    expectedRevenue: 198e8,
    partnerName: "Gemini Furniture",
    email: "sales@gemini.com",
    phone: "+1-555-0108",
    description: "Distributor agreement signed",
    rating: 2,
    createdAt: /* @__PURE__ */ new Date("2026-02-15"),
    updatedAt: /* @__PURE__ */ new Date("2026-03-10"),
    syncedAt: /* @__PURE__ */ new Date()
  },
  {
    id: 9,
    odooId: 1009,
    name: "Devis pour 150 tapis",
    stage: "New",
    amount: 4e10,
    // 40,000,000 K
    probability: 20,
    expectedRevenue: 8e9,
    partnerName: "OpenWood",
    email: "quote@openwood.com",
    phone: "+1-555-0109",
    description: "Quote request for carpets",
    rating: 1,
    createdAt: /* @__PURE__ */ new Date("2026-03-18"),
    updatedAt: /* @__PURE__ */ new Date("2026-03-18"),
    syncedAt: /* @__PURE__ */ new Date()
  },
  {
    id: 10,
    odooId: 1010,
    name: "Will McEnroe Product",
    stage: "New",
    amount: 4e10,
    // 40,000,000 K
    probability: 15,
    expectedRevenue: 6e9,
    partnerName: "Will McEnroe",
    email: "will@example.com",
    phone: "+1-555-0110",
    description: "Product inquiry",
    rating: 1,
    createdAt: /* @__PURE__ */ new Date("2026-03-17"),
    updatedAt: /* @__PURE__ */ new Date("2026-03-17"),
    syncedAt: /* @__PURE__ */ new Date()
  }
];

// server/opportunities-datasource.ts
init_env();
var DATA_SOURCE = process.env.CRM_DATA_SOURCE || "mock";
async function getOpportunitiesFromSource(scope = "team") {
  console.log(`[DataSource] Using data source: ${DATA_SOURCE}`);
  switch (DATA_SOURCE) {
    case "mock":
      return getMockOpportunities();
    case "database":
      return getDatabaseOpportunities();
    case "odoo":
      return getOdooOpportunities(scope);
    default:
      console.warn(`[DataSource] Unknown data source: ${DATA_SOURCE}, falling back to mock`);
      return getMockOpportunities();
  }
}
async function getOpportunitiesByStageFromSource(stage, scope = "team") {
  const all = await getOpportunitiesFromSource(scope);
  return all.filter((o) => o.stage === stage);
}
async function getMetricsFromSource(scope = "team") {
  const all = await getOpportunitiesFromSource(scope);
  const won = all.filter((o) => o.stage === "Won");
  const open = all.filter((o) => o.stage !== "Won");
  const qualified = all.filter((o) => o.stage === "Qualified");
  const totalLeads = all.length;
  const wonOpportunities = won.length;
  const conversionRate = totalLeads > 0 ? Math.round(wonOpportunities / totalLeads * 100) : 0;
  const weightedPipeline = all.reduce((sum, o) => sum + (o.expectedRevenue || 0), 0);
  const wonRevenue = won.reduce((sum, o) => sum + (o.amount || 0), 0);
  const openOpportunities = open.length;
  const idleOpportunities = qualified.length;
  return {
    totalLeads,
    wonOpportunities,
    conversionRate,
    weightedPipeline,
    wonRevenue,
    openOpportunities,
    idleOpportunities
  };
}
async function getMockOpportunities() {
  console.log("[DataSource] Fetching from mock data");
  return mockOpportunities;
}
async function getDatabaseOpportunities() {
  console.log("[DataSource] Fetching from database");
  try {
    return await getAllOpportunities();
  } catch (error) {
    console.error("[DataSource] Database fetch failed, falling back to mock:", error);
    return getMockOpportunities();
  }
}
async function getOdooOpportunities(scope) {
  console.log("[DataSource] Fetching from Odoo");
  try {
    const { getOdooClient: getOdooClient2 } = await Promise.resolve().then(() => (init_odoo(), odoo_exports));
    const client = await getOdooClient2();
    if (!client) {
      console.warn("[DataSource] Odoo client not available, falling back to mock");
      return getMockOpportunities();
    }
    const teamId = ENV.odooTeamId ? Number(ENV.odooTeamId) : void 0;
    const teamName = ENV.odooTeamName || void 0;
    const leadType = ENV.odooLeadType || void 0;
    const userId = ENV.odooUserId ? Number(ENV.odooUserId) : void 0;
    const userName = ENV.odooUserName || void 0;
    const userLogin = ENV.odooUserLogin || void 0;
    let filters = { leadType };
    if (scope === "team") {
      filters = { ...filters, teamId, teamName };
    } else if (scope === "mine") {
      if (userId || userName || userLogin) {
        filters = { ...filters, userId, userName, userLogin };
      } else if (teamId || teamName) {
        console.warn("[DataSource] My Pipeline requested but no user filter set; falling back to team filter.");
        filters = { ...filters, teamId, teamName };
      }
    }
    const leads = await client.getLeads(200, filters);
    const now = /* @__PURE__ */ new Date();
    return leads.map((lead, index) => {
      const odooId = Number(lead.id) || index + 1;
      const stage = Array.isArray(lead.stage_id) ? String(lead.stage_id[1]) : "New";
      const probability = Number(lead.probability ?? 0);
      const expectedRevenue = Math.round(Number(lead.expected_revenue ?? 0) * 1e3);
      const createdAt = lead.create_date ? new Date(String(lead.create_date)) : now;
      const partnerName = Array.isArray(lead.partner_id) ? String(lead.partner_id[1]) : null;
      return {
        id: odooId,
        odooId,
        name: String(lead.name ?? `Lead #${odooId}`),
        stage,
        amount: expectedRevenue,
        probability,
        expectedRevenue,
        partnerName,
        email: lead.email_from ? String(lead.email_from) : null,
        phone: lead.phone ? String(lead.phone) : null,
        description: lead.description ? String(lead.description) : null,
        rating: 0,
        createdAt,
        updatedAt: createdAt,
        syncedAt: now
      };
    });
  } catch (error) {
    console.error("[DataSource] Odoo fetch failed, falling back to mock:", error);
    return getMockOpportunities();
  }
}

// server/odoo-sync.ts
init_env();
import axios3 from "axios";
var OdooSyncService = class {
  baseUrl;
  username;
  password;
  database;
  uid = null;
  constructor(baseUrl, username, password, database) {
    let cleanUrl = baseUrl.replace(/\/$/, "");
    if (cleanUrl.endsWith("/odoo")) {
      cleanUrl = cleanUrl.slice(0, -5);
    }
    this.baseUrl = cleanUrl;
    this.username = username;
    this.password = password;
    this.database = database;
  }
  /**
   * Authenticate with Odoo
   */
  async authenticate() {
    try {
      console.log(`[Odoo Sync] Authenticating at: ${this.baseUrl}/jsonrpc`);
      const response = await axios3.post(
        `${this.baseUrl}/jsonrpc`,
        {
          jsonrpc: "2.0",
          method: "call",
          params: {
            service: "common",
            method: "authenticate",
            args: [this.database, this.username, this.password, {}]
          },
          id: 1
        },
        {
          timeout: 15e3,
          headers: { "Content-Type": "application/json" }
        }
      );
      if (response.data.error || !response.data.result) {
        console.error("[Odoo Sync] Auth failed:", response.data.error);
        return false;
      }
      this.uid = response.data.result;
      console.log(`[Odoo Sync] Authenticated as UID: ${this.uid}`);
      return true;
    } catch (error) {
      console.error("[Odoo Sync] Auth error:", error instanceof Error ? error.message : error);
      return false;
    }
  }
  /**
   * Call Odoo RPC method
   */
  async rpcCall(model, method, args = []) {
    if (!this.uid) {
      throw new Error("Not authenticated");
    }
    try {
      const response = await axios3.post(
        `${this.baseUrl}/jsonrpc`,
        {
          jsonrpc: "2.0",
          method: "call",
          params: {
            service: "object",
            method: "execute",
            args: [this.database, this.uid, this.password, model, method, ...args]
          },
          id: 1
        },
        {
          timeout: 15e3,
          headers: { "Content-Type": "application/json" }
        }
      );
      if (response.data.error) {
        throw new Error(
          typeof response.data.error === "object" ? response.data.error.data?.message || JSON.stringify(response.data.error) : String(response.data.error)
        );
      }
      return response.data.result;
    } catch (error) {
      console.error(`[Odoo Sync] RPC call failed (${model}.${method}):`, error);
      throw error;
    }
  }
  /**
   * Fetch opportunities from Odoo
   */
  async fetchOpportunities() {
    try {
      console.log("[Odoo Sync] Fetching opportunities...");
      const leadIds = await this.rpcCall("crm.lead", "search", [[]]);
      if (!leadIds || leadIds.length === 0) {
        console.log("[Odoo Sync] No opportunities found");
        return [];
      }
      console.log(`[Odoo Sync] Found ${leadIds.length} opportunities`);
      const opportunities2 = await this.rpcCall("crm.lead", "read", [
        leadIds,
        [
          "id",
          "name",
          "stage_id",
          "probability",
          "expected_revenue",
          "partner_id",
          "email_from",
          "phone",
          "description",
          "create_date"
        ]
      ]);
      console.log(`[Odoo Sync] Fetched ${opportunities2.length} opportunities from Odoo`);
      return opportunities2;
    } catch (error) {
      console.error("[Odoo Sync] Failed to fetch opportunities:", error);
      return [];
    }
  }
  /**
   * Sync opportunities to local database
   */
  async syncOpportunities() {
    try {
      const opportunities2 = await this.fetchOpportunities();
      if (opportunities2.length === 0) {
        console.log("[Odoo Sync] No opportunities to sync");
        return 0;
      }
      let synced = 0;
      for (const opp of opportunities2) {
        try {
          await upsertOpportunity(opp.id, {
            name: opp.name,
            stage: opp.stage_id?.[1] || "New",
            amount: Math.round((opp.amount_total || 0) * 1e3),
            // Store in smallest unit
            probability: opp.probability || 0,
            expectedRevenue: Math.round((opp.expected_revenue || 0) * 1e3),
            partnerName: opp.partner_id?.[1] || null,
            email: opp.email_from || null,
            phone: opp.phone || null,
            description: opp.description || null,
            rating: opp.rating || 0
          });
          synced++;
        } catch (error) {
          console.error(`[Odoo Sync] Failed to sync opportunity ${opp.id}:`, error);
        }
      }
      console.log(`[Odoo Sync] Successfully synced ${synced}/${opportunities2.length} opportunities`);
      return synced;
    } catch (error) {
      console.error("[Odoo Sync] Sync failed:", error);
      return 0;
    }
  }
};
var syncService = null;
async function getSyncService() {
  if (!ENV.odooUrl || !ENV.odooUsername || !ENV.odooPassword || !ENV.odooDatabase) {
    console.warn("[Odoo Sync] Missing Odoo credentials");
    return null;
  }
  if (syncService) {
    return syncService;
  }
  syncService = new OdooSyncService(
    ENV.odooUrl,
    ENV.odooUsername,
    ENV.odooPassword,
    ENV.odooDatabase
  );
  const authenticated = await syncService.authenticate();
  if (!authenticated) {
    console.error("[Odoo Sync] Failed to authenticate");
    syncService = null;
    return null;
  }
  return syncService;
}
async function syncOdooData() {
  const service = await getSyncService();
  if (!service) {
    console.error("[Odoo Sync] Cannot sync: service not available");
    return 0;
  }
  return await service.syncOpportunities();
}

// server/routers.ts
var appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true
      };
    })
  }),
  crm: router({
    opportunities: router({
      list: publicProcedure.input(z2.object({ scope: z2.enum(["all", "team", "mine"]).optional() }).optional()).query(async ({ input }) => {
        const scope = input?.scope ?? "team";
        return await getOpportunitiesFromSource(scope);
      }),
      byStage: publicProcedure.input(z2.object({ stage: z2.string(), scope: z2.enum(["all", "team", "mine"]).optional() })).query(async ({ input }) => {
        const scope = input.scope ?? "team";
        return await getOpportunitiesByStageFromSource(input.stage, scope);
      }),
      metrics: publicProcedure.input(z2.object({ scope: z2.enum(["all", "team", "mine"]).optional() }).optional()).query(async ({ input }) => {
        const scope = input?.scope ?? "team";
        return await getMetricsFromSource(scope);
      }),
      sync: publicProcedure.mutation(async () => {
        const synced = await syncOdooData();
        return { success: true, synced };
      })
    })
  })
});

// server/_core/context.ts
async function createContext(opts) {
  let user = null;
  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    user = null;
  }
  return {
    req: opts.req,
    res: opts.res,
    user
  };
}

// server/_core/vite.ts
import express from "express";
import fs2 from "fs";
import { nanoid } from "nanoid";
import path2 from "path";
import { createServer as createViteServer } from "vite";

// vite.config.ts
import { jsxLocPlugin } from "@builder.io/vite-plugin-jsx-loc";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import fs from "node:fs";
import path from "node:path";
import { defineConfig } from "vite";
import { vitePluginManusRuntime } from "vite-plugin-manus-runtime";
var PROJECT_ROOT = import.meta.dirname;
var LOG_DIR = path.join(PROJECT_ROOT, ".manus-logs");
var MAX_LOG_SIZE_BYTES = 1 * 1024 * 1024;
var TRIM_TARGET_BYTES = Math.floor(MAX_LOG_SIZE_BYTES * 0.6);
function ensureLogDir() {
  if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
  }
}
function trimLogFile(logPath, maxSize) {
  try {
    if (!fs.existsSync(logPath) || fs.statSync(logPath).size <= maxSize) {
      return;
    }
    const lines = fs.readFileSync(logPath, "utf-8").split("\n");
    const keptLines = [];
    let keptBytes = 0;
    const targetSize = TRIM_TARGET_BYTES;
    for (let i = lines.length - 1; i >= 0; i--) {
      const lineBytes = Buffer.byteLength(`${lines[i]}
`, "utf-8");
      if (keptBytes + lineBytes > targetSize) break;
      keptLines.unshift(lines[i]);
      keptBytes += lineBytes;
    }
    fs.writeFileSync(logPath, keptLines.join("\n"), "utf-8");
  } catch {
  }
}
function writeToLogFile(source, entries) {
  if (entries.length === 0) return;
  ensureLogDir();
  const logPath = path.join(LOG_DIR, `${source}.log`);
  const lines = entries.map((entry) => {
    const ts = (/* @__PURE__ */ new Date()).toISOString();
    return `[${ts}] ${JSON.stringify(entry)}`;
  });
  fs.appendFileSync(logPath, `${lines.join("\n")}
`, "utf-8");
  trimLogFile(logPath, MAX_LOG_SIZE_BYTES);
}
function vitePluginManusDebugCollector() {
  return {
    name: "manus-debug-collector",
    transformIndexHtml(html) {
      if (process.env.NODE_ENV === "production") {
        return html;
      }
      return {
        html,
        tags: [
          {
            tag: "script",
            attrs: {
              src: "/__manus__/debug-collector.js",
              defer: true
            },
            injectTo: "head"
          }
        ]
      };
    },
    configureServer(server) {
      server.middlewares.use("/__manus__/logs", (req, res, next) => {
        if (req.method !== "POST") {
          return next();
        }
        const handlePayload = (payload) => {
          if (payload.consoleLogs?.length > 0) {
            writeToLogFile("browserConsole", payload.consoleLogs);
          }
          if (payload.networkRequests?.length > 0) {
            writeToLogFile("networkRequests", payload.networkRequests);
          }
          if (payload.sessionEvents?.length > 0) {
            writeToLogFile("sessionReplay", payload.sessionEvents);
          }
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ success: true }));
        };
        const reqBody = req.body;
        if (reqBody && typeof reqBody === "object") {
          try {
            handlePayload(reqBody);
          } catch (e) {
            res.writeHead(400, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: String(e) }));
          }
          return;
        }
        let body = "";
        req.on("data", (chunk) => {
          body += chunk.toString();
        });
        req.on("end", () => {
          try {
            const payload = JSON.parse(body);
            handlePayload(payload);
          } catch (e) {
            res.writeHead(400, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: String(e) }));
          }
        });
      });
    }
  };
}
var plugins = [react(), tailwindcss(), jsxLocPlugin(), vitePluginManusRuntime(), vitePluginManusDebugCollector()];
var vite_config_default = defineConfig({
  plugins,
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  envDir: path.resolve(import.meta.dirname),
  root: path.resolve(import.meta.dirname, "client"),
  publicDir: path.resolve(import.meta.dirname, "client", "public"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    host: true,
    allowedHosts: [
      ".manuspre.computer",
      ".manus.computer",
      ".manus-asia.computer",
      ".manuscomputer.ai",
      ".manusvm.computer",
      "localhost",
      "127.0.0.1"
    ],
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/_core/vite.ts
async function setupVite(app, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    server: serverOptions,
    appType: "custom"
  });
  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "../..",
        "client",
        "index.html"
      );
      let template = await fs2.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app) {
  const distPath = process.env.NODE_ENV === "development" ? path2.resolve(import.meta.dirname, "../..", "dist", "public") : path2.resolve(import.meta.dirname, "public");
  if (!fs2.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app.use(express.static(distPath));
  app.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/_core/index.ts
if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = "development";
}
function isPortAvailable(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}
async function findAvailablePort(startPort = 3e3) {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}
async function startServer() {
  const app = express2();
  const server = createServer(app);
  app.use(express2.json({ limit: "50mb" }));
  app.use(express2.urlencoded({ limit: "50mb", extended: true }));
  registerOAuthRoutes(app);
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext
    })
  );
  if (process.env.NODE_ENV !== "production") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);
  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }
  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
startServer().catch(console.error);
